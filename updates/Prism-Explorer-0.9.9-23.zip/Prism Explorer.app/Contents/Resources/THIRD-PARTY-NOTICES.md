# Third-party notices

## vgpu examples (shader sources)

`Sources/PrismExplorer/AmbientEffects.swift` contains Metal ports of two
fragment programs adapted from the vgpu examples `holographic-card` ("sheen")
and `nextjs-flare` ("flare"), by way of the WebGPU adaptation in the
cdt-admin "lightfx" loader (vgpu 0.5.0, revision
6fa27bb458ffc3f498727090f09dce3fe5faabb43689fd669d633a2a23dc36bb).

MIT License

Copyright (c) 2025 Vercel, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Sparkle

The updater framework is bundled with its own licence as
`Sparkle-LICENSE.txt` inside the application bundle.
